ADMOTION CLIENT MANAGER - ANDROID APK BUILD

Ye Android project hai. APK free GitHub Actions se build ho sakta hai.

PHONE SE BUILD KARNE KE STEPS:
1. GitHub.com par account/login karo.
2. New repository banao, naam: admotion-client-manager-apk
3. Is ZIP ko extract karo. Extracted folder ke andar ki saari files/folders repository ke root me upload karo. .github folder bhi upload hona chahiye.
4. GitHub repository me Actions tab kholo.
5. 'Build Android APK' workflow select karo.
6. 'Run workflow' dabao.
7. Build complete hone par workflow run kholo, neeche Artifacts me 'AdMotion-Client-Manager-APK' download karo.
8. ZIP extract karo. app-debug.apk milega. Phone me install karo (unknown apps permission allow karni pad sakti hai).

NOTE:
- Ye standalone Android app hai; Chrome/Google ki zarurat nahi.
- Client data app ke local storage me isi phone par rahega. Backup feature use karte rehna.
- Debug APK personal use/testing ke liye hai. Play Store release ke liye signed release build alag se banana hoga.
